%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Path Following Algorithm for UAV in Time Varying Wind %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Attribution information
% This Matlab/Simulink file was designed for the SC42040 - Adaptive and Predictive
% Control course in Delft University of Technology. The core project was
% created by Bingyu Zhou (b.zhou-2@student.tudelft.nl).

%%
close all;clear;clc;
%% Initialization

%!!!!! Do not change the variables' name below !!!!
W = 6;       %constant wind velocity(m/s)
phiw = 230/180*pi;%constant wind direction(rad)
Va = 13;        %Longitudinal velocity(m/s)
A = 3;     % Time varying wind's amplitude (variance)
phiA = pi;    %Time varying wind's angle (variance)
chi_inf = pi/2;    %course angle far away from path (rad)
alpha = 1.65;      %positive constant describe the speed of response of course
                    %hold autopilot loop (rad/s)

                    
% These are the varibales you need to tune. Here is just an example for you. 
% You can change the variable name, but do understand the meaning of each variable.
k = 2;      %positive constant influence the rate of the transition from
            %x_inf to zero, also control the slope of the sliding surface near the origin(m^-1)
            
kk = 2;      %gain parameter controls the shape of the trajectories onto the sliding surface.(rad^2/s)

epsi = 2;     %width of the transition region around the sliding surface which is used to 
              %reduce chattering in the control.(rad)

Gamma = 2;   %Estimator gain 


%% ------------------------------------
% ---------Stright line following------
% -------------------------------------
% Initial conditions. Change it to your favorite values. But do not change
% the varibale name!
% Initial posture of UAV
x_int = 0;
y_int = 80;
course_int = pi/4;

% Reference
% Give the reference path function y = ax+b here


% Initial value of Vg'
% Help you to find the initial value of ground velocity. You will need it
% in the estimator. Do not need to read this function.
Vg0 = InitialVg(A,0,W,phiw,Va,course_int);

% Simulation of stright line following.
% You can implement the controller and estimator in Simulink. Enjoy!
simout=sim('AdaptiveVF_Line');


% %% -----------------------------
% % ---------Orbit following------
% % ------------------------------
%Initial conditions. Change it to your favorite values. But do not change
%the variable name!
%initial position and posture in polar coordinate
d_int = 15; 
course_int = -pi/4; 
gamma_int = pi/4; 

% Reference (You can change the value, but do not change the variable name!) 
cx = 20; 
cy = 20;% (cx,cy) is the orbit center
R = 20;% orbit radius

% Initial value of Vg'
% Help you to find the initial value of ground velocity. You will need it
% in the estimator. Do not need to read this function.
Vg0 = InitialVg(A,0,W,phiw,Va,course_int);

% Simulation of orbit following
% You can implement the controller and estimator in Simulink. Enjoy!
simout=sim('AdaptiveVF_Orbit');




